/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package savingaccount;

public class SavingAccount {
    double annualInterestRate;
    private double savingBalance;

    void MonthlyInterest(){
        MonthlyInterest = savingBalance * (annualInterestRate / 12);
        savingBalance = savingBalance + MonthlyInterest;
        
        System.out.println("Current saving balance: " + savingBalance);
        System.out.println("Monthly Interest :" + MonthlyInterest);
        }

       SavingAccount(double annualInterestRate , double savingBalance){
        this.annualInterestRate = annualInterestRate;
        this.savingBalance = savingBalance;
    }

        static void modifyInterestRate(double newInterestRate){
            annualInterestRate = newInterestRate;
    }
  
}
